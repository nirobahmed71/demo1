window.addEventListener('scroll',function(){
    var nav=this.document.querySelector('.content');
   nav.classList.toggle('sticky',this.window.scrollY>42);
})